import SearchPage from '@/components/search/SearchPage'
import React from 'react'

const searchPage = () => {
    return (
        <>
            <SearchPage />
        </>
    )   
}

export default searchPage
