import SearchPage from '@/components/search/SearchPage'
import React from 'react'

const searchPage = async ({ params }) => {

    const { slug } = await params;

    return (
        <>
            <SearchPage slug={slug} />
        </>
    )
}

export default searchPage
