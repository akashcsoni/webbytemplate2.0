import React from 'react'

const page = () => {
    return (
        <div>
            Search Page
        </div>
    )
}

export default page
