import { redirect } from "next/navigation"

export default function AccountPage() {
  redirect("/author/account/orders")
}
