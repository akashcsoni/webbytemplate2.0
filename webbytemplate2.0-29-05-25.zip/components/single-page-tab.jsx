"use client";

import React, { useState, useMemo } from "react";
import FaqSection from "./FaqSection";
import ReviewList from "./product/review-list";

const tabs = [
  { key: "overview", title: "Overview" },
  { key: "reviews", title: "Reviews" },
  { key: "changelog", title: "Changelog" },
  { key: "faq", title: "FAQ" },
];

const SinglePageTab = ({ data }) => {
  const [activeTab, setActiveTab] = useState("overview");

  const renderContent = useMemo(() => {
    switch (activeTab) {
      case "overview":
        return data?.overview_description ? (
          <div
            className="space-y-4"
            dangerouslySetInnerHTML={{ __html: data.overview_description }}
          />
        ) : (
          <p>No overview available.</p>
        );

      case "reviews":
        return data?.slug ? (
          <div className="sm:space-y-8 space-y-4">
            <ReviewList slug={data.slug} />
          </div>
        ) : (
          <p>No reviews found.</p>
        );

      case "changelog":
        return Array.isArray(data?.changelogs) && data.changelogs.length > 0 ? (
          <div className="space-y-5">
            {data.changelogs.map((entry, index) => (
              <div key={index} className="flex flex-col gap-2">
                <div className="flex items-center justify-between w-full">
                  <p className="font-bold text-primary">{entry?.version || "v?"}</p>
                  <p className="text-sm text-gray-500">{entry?.date || "Unknown date"}</p>
                </div>
                <p className="bg-blue-300 w-full px-3 py-1 rounded border border-primary/10 font-mono text-sm text-black tracking-normal">
                  - {entry?.note || "No notes provided."}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <p>No changelog available.</p>
        );

      case "faq":
        return data?.faq?.length > 0 ? (
          <FaqSection list={data.faq} type="full" />
        ) : (
          <p>No FAQs available.</p>
        );

      default:
        return <p>Invalid tab selection.</p>;
    }
  }, [activeTab, data]);

  return (
    <div className="w-full flex flex-col">
      {/* Tabs */}
      <div className="flex border-b border-primary/10 overflow-auto">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-4 py-2 transition-all duration-200 border-b-2 ${activeTab === tab.key
                ? "border-blue-600 text-blue-600"
                : "text-gray-600 hover:text-blue-600 border-transparent"
              } bg-transparent`}
          >
            {tab.title}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="sm:mt-6 mt-3 space-y-6">{renderContent}</div>
    </div>
  );
};

export default SinglePageTab;
